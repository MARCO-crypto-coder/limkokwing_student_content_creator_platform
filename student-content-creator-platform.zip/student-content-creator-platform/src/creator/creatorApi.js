import { initialContent } from "./content.js";

const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000/api";
const STORAGE_KEY = "mpho-content-preview";
const VIEWER_ID_KEY = "mpho-viewer-id";
const LIKED_STORIES_KEY = "mpho-liked-stories";

function viewerId() {
  let id = localStorage.getItem(VIEWER_ID_KEY);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(VIEWER_ID_KEY, id);
  }
  return id;
}

export function likedStories() {
  try {
    return JSON.parse(localStorage.getItem(LIKED_STORIES_KEY) || "[]");
  } catch {
    return [];
  }
}

function rememberLike(id) {
  const liked = new Set(likedStories());
  liked.add(id);
  localStorage.setItem(LIKED_STORIES_KEY, JSON.stringify([...liked]));
}

function normalizeContent(items) {
  return items.map((item) => ({ ...item, id: item.id || item._id }));
}

function localContent() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    const items = normalizeContent(saved ? JSON.parse(saved) : initialContent);
    const existingIds = new Set(items.map((item) => item.id));
    return [...items, ...initialContent.filter((item) => !existingIds.has(item.id))];
  } catch {
    return initialContent;
  }
}

function saveLocal(items) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  return items;
}

async function request(path, options = {}, token) {
  const response = await fetch(`${API_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.message || "The request could not be completed.");
  return result;
}

export async function fetchPublicContent() {
  try {
    return normalizeContent(await request("/content"));
  } catch {
    return localContent().filter((item) => item.status === "published");
  }
}

export async function fetchCreatorContent(token) {
  return normalizeContent(await request("/creator/content", {}, token));
}

export async function loginCreator(email, password) {
  return request("/auth/login", { method: "POST", body: JSON.stringify({ email, password }) });
}

export async function signupCreator(email, password) {
  return request("/auth/signup", { method: "POST", body: JSON.stringify({ email, password }) });
}

export async function loginWithGoogle(credential) {
  return request("/auth/google", { method: "POST", body: JSON.stringify({ credential }) });
}

export async function saveContent(post, token) {
  try {
    const path = post.id ? `/creator/content/${post.id}` : "/creator/content";
    const method = post.id ? "PUT" : "POST";
    const result = await request(path, { method, body: JSON.stringify(post) }, token);
    return { ...result, id: result.id || result._id };
  } catch (error) {
    if (error.message !== "Failed to fetch") throw error;
    const items = localContent();
    const item = { ...post, id: post.id || `local-${Date.now()}` };
    const next = post.id ? items.map((entry) => entry.id === post.id ? item : entry) : [item, ...items];
    saveLocal(next);
    return item;
  }
}

export async function removeContent(id, token) {
  try {
    await request(`/creator/content/${id}`, { method: "DELETE" }, token);
  } catch (error) {
    if (error.message !== "Failed to fetch") throw error;
    saveLocal(localContent().filter((item) => item.id !== id));
  }
}

export async function toggleLike(id) {
  if (likedStories().includes(id)) {
    return { ...localContent().find((item) => item.id === id), liked: true, alreadyLiked: true };
  }
  try {
    const result = await request(`/content/${id}/like`, { method: "POST", headers: { "X-Viewer-Id": viewerId() } });
    rememberLike(id);
    return { ...result, id: result.id || result._id };
  } catch {
    const items = localContent().map((item) => item.id === id ? { ...item, likes: (item.likes || 0) + 1 } : item);
    saveLocal(items);
    rememberLike(id);
    return items.find((item) => item.id === id);
  }
}

export async function recordView(id) {
  try {
    const result = await request(`/content/${id}/view`, { method: "POST" });
    return { ...result, id: result.id || result._id };
  } catch {
    const items = localContent().map((item) => item.id === id ? { ...item, views: (item.views || 0) + 1 } : item);
    saveLocal(items);
    return items.find((item) => item.id === id);
  }
}

export async function postComment(id, text, name = "Guest viewer") {
  const comment = { id: `comment-${Date.now()}`, name, text, date: "Just now", approved: false, reply: "" };
  try {
    const result = await request(`/content/${id}/comments`, { method: "POST", body: JSON.stringify({ text, name }) });
    return { ...result, id: result.id || result._id };
  } catch {
    const items = localContent().map((item) => item.id === id ? { ...item, comments: [...(item.comments || []), comment] } : item);
    saveLocal(items);
    return items.find((item) => item.id === id);
  }
}