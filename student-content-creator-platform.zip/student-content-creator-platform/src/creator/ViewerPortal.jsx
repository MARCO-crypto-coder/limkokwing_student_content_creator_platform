import { useEffect, useRef, useState } from "react";
import { categories } from "./content.js";
import { likedStories } from "./creatorApi.js";

const videoPlaylist = [
  {
    title: "A quiet place to begin",
    mood: "FIELD NOTES / 01",
    src: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
    poster: "https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=1600&q=85",
  },
  {
    title: "The long way home",
    mood: "SLOW TRAVEL / 02",
    src: "https://media.w3.org/2010/05/sintel/trailer.mp4",
    poster: "https://images.unsplash.com/photo-1470770841072-f978cf4d019e?auto=format&fit=crop&w=1600&q=85",
  },
  {
    title: "A little room to roam",
    mood: "OPEN LAND / 03",
    src: "https://media.w3.org/2010/05/bunny/trailer.mp4",
    poster: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1600&q=85",
  },
];

function formatNumber(number) {
  return new Intl.NumberFormat("en", { notation: "compact", maximumFractionDigits: 1 }).format(number || 0);
}

export default function ViewerPortal({ posts, onLike, onComment, onView }) {
  const curiosityRef = useRef(null);
  const [curiosityVisible, setCuriosityVisible] = useState(false);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All stories");
  const [selected, setSelected] = useState(null);
  const [comment, setComment] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [notice, setNotice] = useState("");
  const [likedIds, setLikedIds] = useState(() => new Set(likedStories()));
  const [activeVideoIndex, setActiveVideoIndex] = useState(0);
  const [videoFailed, setVideoFailed] = useState(false);
  const published = posts.filter((post) => post.status === "published");
  const activeVideo = videoPlaylist[activeVideoIndex];
  const featured = published[0];
  const visible = published.filter((post) => {
    const matchesCategory = category === "All stories" || post.category === category;
    const haystack = `${post.title} ${post.description} ${post.category}`.toLowerCase();
    return matchesCategory && haystack.includes(query.toLowerCase());
  });

  useEffect(() => {
    const word = curiosityRef.current;
    if (!word) return undefined;
    if (!("IntersectionObserver" in window)) {
      setCuriosityVisible(true);
      return undefined;
    }
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setCuriosityVisible(true);
        observer.disconnect();
      }
    }, { threshold: 0.6 });
    observer.observe(word);
    return () => observer.disconnect();
  }, []);

  async function openStory(post) {
    setSelected(post);
    setNotice("");
    setSelected(await onView(post.id));
  }

  async function submitComment(event) {
    event.preventDefault();
    if (!comment.trim() || !selected) return;
    const updated = await onComment(selected.id, comment.trim(), displayName.trim() || "Guest viewer");
    setSelected(updated);
    setComment("");
    setDisplayName("");
    setNotice("Thanks for joining in. Your comment will appear after review.");
  }

  async function shareSelected() {
    const shareData = { title: selected.title, text: selected.description, url: selected.mediaUrl };
    try {
      if (navigator.share) await navigator.share(shareData);
      else {
        await navigator.clipboard.writeText(selected.mediaUrl);
        setNotice("Content link copied.");
      }
    } catch (error) {
      if (error.name !== "AbortError") setNotice("Could not share this link.");
    }
  }

  async function likeSelected() {
    if (likedIds.has(selected.id)) return;
    const updated = await onLike(selected.id);
    setSelected(updated);
    setLikedIds((current) => new Set(current).add(selected.id));
  }

  async function likeStory(event, post) {
    event.stopPropagation();
    if (likedIds.has(post.id)) return;
    const updated = await onLike(post.id);
    setLikedIds((current) => new Set(current).add(post.id));
    if (selected?.id === post.id) setSelected(updated);
  }

  function selectVideo(index) {
    setActiveVideoIndex((index + videoPlaylist.length) % videoPlaylist.length);
    setVideoFailed(false);
  }

  return (
    <main className="portal">
      <section className="intro-band" id="home">
        <div className="intro-copy">
          <p className="eyebrow"><span className="eyebrow-mark" /> INDEPENDENT CREATOR / MASERU, LS</p>
          <h1>Make room<br />for <em ref={curiosityRef} className={curiosityVisible ? "curiosity-word is-visible" : "curiosity-word"}><span>curiosity</span>.</em></h1>
          <p className="intro-description">I’m Mpho. I make thoughtful stories about creative work, everyday life, and the places that shape us.</p>
          <a className="text-link" href="#stories">Explore the stories <span aria-hidden="true">↘</span></a>
        </div>
        <div className="intro-art">
          <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=85" alt="Portrait of creator Mpho Nthebe" />
          <div className="portrait-stamp"><span>GOOD<br />THINGS<br />TAKE<br /><i>noticing</i></span></div>
          <div className="portrait-caption">A LITTLE MORE HERE,<br />A LITTLE LESS ELSEWHERE.</div>
        </div>
        <div className="intro-index">01 / THE JOURNAL</div>
      </section>

      <section className="featured-strip" aria-label="Featured story">
        <div className="featured-label"><span className="label-line" /> THIS WEEK’S PICK</div>
        {featured && <button className="featured-story" type="button" onClick={() => openStory(featured)}>
          <span>{featured.title}</span><span className="featured-arrow" aria-hidden="true">↗</span>
        </button>}
        <p>Stories, notes, and new perspectives from the highlands.</p>
      </section>

      <section className="story-section" id="stories">
        <div className="section-heading">
          <div><p className="eyebrow">THE LIBRARY</p><h2>Latest stories<span className="heading-period">.</span></h2></div>
          <label className="search-box"><span aria-hidden="true">⌕</span><input type="search" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search stories" aria-label="Search stories" /></label>
        </div>
        <div className="filter-row" role="group" aria-label="Filter by category">
          {categories.map((item) => <button key={item} className={category === item ? "filter-chip selected" : "filter-chip"} type="button" onClick={() => setCategory(item)}>{item}</button>)}
          <span className="story-count">{visible.length} {visible.length === 1 ? "story" : "stories"}</span>
        </div>
        <div className="story-grid">
          {visible.map((post, index) => <article className={`story-card story-card-${index % 3}`} key={post.id}>
            <button className="story-image" type="button" onClick={() => openStory(post)} aria-label={`Read ${post.title}`}>
              <img src={post.cover} alt="" loading="lazy" />
              <span className="image-arrow" aria-hidden="true">↗</span>
            </button>
            <div className="story-meta"><span>{post.category}</span><span>{post.readTime}</span></div>
            <button className="story-title" type="button" onClick={() => openStory(post)}>{post.title}</button>
            <p>{post.description}</p>
            <div className="story-foot"><span>{new Date(post.publishedAt).toLocaleDateString("en", { month: "short", day: "numeric" })}</span><button className={likedIds.has(post.id) ? "story-like is-liked" : "story-like"} type="button" onClick={(event) => likeStory(event, post)} aria-label={likedIds.has(post.id) ? "Already liked" : "Like story"} aria-pressed={likedIds.has(post.id)} disabled={likedIds.has(post.id)}>♡ {formatNumber(post.likes)}</button></div>
          </article>)}
          {visible.length === 0 && <p className="empty-results">No stories found. Try another search or category.</p>}
        </div>
      </section>

      <section className="video-feature" aria-label="The moving journal">
        <div className="video-stage">
          <video
            key={activeVideo.src}
            className="video-player"
            controls
            playsInline
            preload="metadata"
            poster={activeVideo.poster}
            onError={() => setVideoFailed(true)}
            onEnded={() => selectVideo(activeVideoIndex + 1)}
            aria-label={activeVideo.title}
          >
            <source src={activeVideo.src} type="video/mp4" />
            Your browser does not support embedded video.
          </video>
          <div className="video-caption" aria-live="polite">
            <span>{activeVideo.mood}</span>
            <h2>{activeVideo.title}</h2>
          </div>
          {videoFailed && <div className="video-error" role="status">
            <p>This film could not load from its source.</p>
            <a href={activeVideo.src} target="_blank" rel="noreferrer">Open video source ↗</a>
            <button type="button" onClick={() => { setVideoFailed(false); selectVideo(activeVideoIndex); }}>Try again</button>
          </div>}
          <div className="video-controls" aria-label="Video playlist controls">
            <button type="button" onClick={() => selectVideo(activeVideoIndex - 1)} aria-label="Previous film">←</button>
            <span>{String(activeVideoIndex + 1).padStart(2, "0")} / {String(videoPlaylist.length).padStart(2, "0")}</span>
            <button type="button" onClick={() => selectVideo(activeVideoIndex + 1)} aria-label="Next film">→</button>
          </div>
        </div>
        <div className="video-stack" aria-label="Choose a film">
          <p className="video-stack-label">THE MOVING JOURNAL <span>SELECT A FILM</span></p>
          <div className="video-stack-list">
            {videoPlaylist.map((video, index) => <button
              key={video.src}
              type="button"
              className={`video-stack-item${index === activeVideoIndex ? " is-active" : ""}`}
              onClick={() => selectVideo(index)}
              aria-current={index === activeVideoIndex ? "true" : undefined}
            >
              <span className="video-stack-image"><img src={video.poster} alt="" loading="lazy" /><span aria-hidden="true">▶</span></span>
              <span className="video-stack-copy"><small>{video.mood}</small><strong>{video.title}</strong></span>
              <span className="video-stack-number">{String(index + 1).padStart(2, "0")}</span>
            </button>)}
          </div>
        </div>
      </section>

      {selected && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setSelected(null); }}>
        <section className="story-modal" role="dialog" aria-modal="true" aria-labelledby="story-modal-title">
          <button className="icon-button modal-close" type="button" onClick={() => setSelected(null)} aria-label="Close story">×</button>
          <img className="modal-image" src={selected.cover} alt="" />
          <div className="modal-body">
            <p className="eyebrow">{selected.category} <span>·</span> {new Date(selected.publishedAt).toLocaleDateString("en", { month: "long", day: "numeric", year: "numeric" })}</p>
            <h2 id="story-modal-title">{selected.title}</h2>
            <p className="modal-description">{selected.description}</p>
            <div className="modal-actions"><a className="button button-dark" href={selected.mediaUrl} target="_blank" rel="noreferrer">Open the story <span aria-hidden="true">↗</span></a><button type="button" className="like-button" onClick={likeSelected} disabled={likedIds.has(selected.id)} aria-pressed={likedIds.has(selected.id)}>{likedIds.has(selected.id) ? "♥ Liked" : "♡ Like"} · {formatNumber(selected.likes)} likes</button><button type="button" className="like-button" onClick={shareSelected}>Share ↗</button></div>
            <div className="comments-area">
              <h3>Conversation <span>{(selected.comments || []).filter((item) => item.approved).length}</span></h3>
              {(selected.comments || []).filter((item) => item.approved).map((item) => <div className="comment" key={item.id}><div className="comment-avatar">{item.name.charAt(0)}</div><div><div className="comment-byline"><strong>{item.name}</strong><time>{item.date}</time></div><p>{item.text}</p>{item.reply && <div className="creator-reply"><strong>Mpho</strong><p>{item.reply}</p></div>}</div></div>)}
              {notice && <p className="notice-message">{notice}</p>}
              <form className="comment-form" onSubmit={submitComment}><label htmlFor="comment-name">Your name</label><input id="comment-name" value={displayName} onChange={(event) => setDisplayName(event.target.value)} maxLength={80} placeholder="Guest viewer" /><label htmlFor="comment">Add to the conversation</label><textarea id="comment" rows="3" value={comment} onChange={(event) => setComment(event.target.value)} placeholder="Leave a thoughtful note..." required /><button className="button button-dark" type="submit">Post comment <span aria-hidden="true">↗</span></button></form>
            </div>
          </div>
        </section>
      </div>}
    </main>
  );
}