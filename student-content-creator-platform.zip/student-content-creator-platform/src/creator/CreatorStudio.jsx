import { useState } from "react";
import { GoogleLogin } from "@react-oauth/google";

const emptyForm = { title: "", description: "", category: "Field notes", status: "draft", mediaUrl: "", cover: "" };

function numberLabel(value) {
  return new Intl.NumberFormat("en", { notation: "compact", maximumFractionDigits: 1 }).format(value || 0);
}

export default function CreatorStudio({ posts, token, onLogin, onSignup, onGoogleLogin, onLogout, onSave, onDelete }) {
  const [section, setSection] = useState("Overview");
  const [login, setLogin] = useState({ email: "", password: "" });
  const [loginError, setLoginError] = useState("");
  const [authMode, setAuthMode] = useState("login");
  const [googleError, setGoogleError] = useState("");
  const [form, setForm] = useState(null);
  const [formError, setFormError] = useState("");
  const [commentDrafts, setCommentDrafts] = useState({});

  async function submitLogin(event) {
    event.preventDefault();
    setLoginError("");
    try {
      if (authMode === "signup") await onSignup(login.email, login.password);
      else await onLogin(login.email, login.password);
    } catch (error) {
      setLoginError(error.message || "Unable to sign in. Check your connection and details.");
    }
  }

  async function submitContent(event) {
    event.preventDefault();
    setFormError("");
    try {
      await onSave({ ...form, publishedAt: form.publishedAt || new Date().toISOString().slice(0, 10), views: form.views || 0, likes: form.likes || 0, comments: form.comments || [], readTime: form.readTime || "New story" });
      setForm(null);
    } catch (error) {
      setFormError(error.message || "Could not save this story.");
    }
  }

  async function updateComment(post, comment, changes) {
    const next = { ...post, comments: post.comments.map((item) => item.id === comment.id ? { ...item, ...changes } : item) };
    try {
      await onSave(next);
    } catch (error) {
      setFormError(error.message || "Could not update the comment.");
    }
  }

  const published = posts.filter((post) => post.status === "published");
  const draftCount = posts.filter((post) => post.status === "draft").length;
  const scheduledCount = posts.filter((post) => post.status === "scheduled").length;
  const comments = posts.flatMap((post) => (post.comments || []).map((comment) => ({ ...comment, post })));
  const totalViews = published.reduce((total, post) => total + (post.views || 0), 0);
  const totalLikes = published.reduce((total, post) => total + (post.likes || 0), 0);

  if (!token) return (
    <main className="studio-login-wrap">
      <section className="login-panel">
        <div className="login-aside"><span className="login-mark">M.</span><p className="eyebrow">MPHO NTHEBE / PRIVATE AREA</p><h1>Your ideas,<br />in good hands.</h1><p>Sign in to shape what comes next.</p></div>
        <form className="login-form" onSubmit={submitLogin}>
          <p className="eyebrow">CREATOR STUDIO</p><h2>{authMode === "signup" ? "Create your account." : "Welcome back."}</h2>
          <div className="auth-switch" role="group" aria-label="Account action"><button type="button" className={authMode === "login" ? "active" : ""} onClick={() => { setAuthMode("login"); setLoginError(""); }}>Sign in</button><button type="button" className={authMode === "signup" ? "active" : ""} onClick={() => { setAuthMode("signup"); setLoginError(""); }}>Sign up</button></div>
          <label htmlFor="creator-email">Email address</label><input id="creator-email" type="email" autoComplete="email" value={login.email} onChange={(event) => setLogin({ ...login, email: event.target.value })} required />
          <label htmlFor="creator-password">Password</label><input id="creator-password" type="password" autoComplete={authMode === "signup" ? "new-password" : "current-password"} minLength={authMode === "signup" ? 12 : undefined} value={login.password} onChange={(event) => setLogin({ ...login, password: event.target.value })} required />
          {loginError && <p className="form-error" role="alert">{loginError}</p>}
          <button className="button button-dark login-submit" type="submit">{authMode === "signup" ? "Create account" : "Sign in"} <span aria-hidden="true">↗</span></button>
          {process.env.REACT_APP_GOOGLE_CLIENT_ID && <div className="google-auth"><span>OR</span><GoogleLogin onSuccess={async ({ credential }) => { setGoogleError(""); try { await onGoogleLogin(credential); } catch (error) { setGoogleError(error.message || "Google sign-in failed."); } }} onError={() => setGoogleError("Google sign-in failed. Please try again.")} /></div>}
          {googleError && <p className="form-error" role="alert">{googleError}</p>}
          <p className="login-caption">{authMode === "signup" ? "Use at least 12 characters. Creator accounts share access to the studio content." : "Sign in with your creator account or server-configured credentials."}</p>
        </form>
      </section>
    </main>
  );

  return (
    <main className="studio-shell">
      <aside className="studio-sidebar">
        <div className="sidebar-identity"><span className="avatar-m">M</span><div><strong>Mpho Nthebe</strong><small>Creator account</small></div></div>
        <p className="sidebar-label">WORKSPACE</p>
        <nav className="studio-menu" aria-label="Studio sections">
          {["Overview", "Content", "Comments"].map((item) => <button key={item} type="button" className={section === item ? "studio-link active" : "studio-link"} onClick={() => setSection(item)}><span className={`menu-mark mark-${item.toLowerCase()}`} aria-hidden="true" />{item}{item === "Comments" && <span className="menu-count">{comments.filter((comment) => !comment.approved).length || ""}</span>}</button>)}
        </nav>
        <div className="sidebar-bottom"><span className="status-indicator" /> All systems operational<button type="button" onClick={onLogout}>Sign out <span aria-hidden="true">↗</span></button></div>
      </aside>
      <section className="studio-main">
        <div className="studio-topline"><div><p className="eyebrow">MONDAY, NOVEMBER 9, 2026</p><h1>{section === "Overview" ? "Good morning, Mpho" : section}</h1></div><button className="button button-lime" type="button" onClick={() => setForm({ ...emptyForm })}>＋ New story</button></div>
        {formError && <p className="form-error" role="alert">{formError}</p>}
        {section === "Overview" && <>
          <div className="metric-row"><div className="metric-card metric-views"><span>TOTAL / CONTENT ITEMS</span><strong>{posts.length.toString().padStart(2, "0")}</strong><small>{published.length} published · {draftCount} drafts</small><div className="mini-bars" aria-label="Content overview"><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /><i /></div></div><div className="metric-card"><span>ENGAGEMENT / VIEWS & LIKES</span><strong>{numberLabel(totalViews + totalLikes)}</strong><small>{numberLabel(totalViews)} views · {numberLabel(totalLikes)} likes</small><div className="metric-spark">↗</div></div><div className="metric-card"><span>COMMUNITY / COMMENTS</span><strong>{comments.length.toString().padStart(2, "0")}</strong><small>{comments.filter((comment) => !comment.approved).length} pending · {scheduledCount} scheduled</small><div className="metric-spark spark-lime">✳</div></div></div>
          <div className="studio-columns"><section className="studio-table-section"><div className="subsection-heading"><div><p className="eyebrow">YOUR WORK</p><h2>Recent stories</h2></div><button className="quiet-link" type="button" onClick={() => setSection("Content")}>View all <span aria-hidden="true">↗</span></button></div><ContentTable posts={posts.slice(0, 4)} onEdit={(post) => setForm({ ...post })} onDelete={onDelete} /></section><section className="inbox-preview"><div className="subsection-heading"><div><p className="eyebrow">COMMUNITY</p><h2>Needs a reply</h2></div><button className="quiet-link" type="button" onClick={() => setSection("Comments")}>All comments <span aria-hidden="true">↗</span></button></div>{comments.filter((item) => item.approved && !item.reply).slice(0, 3).map((item) => <div className="inbox-item" key={item.id}><div className="comment-avatar">{item.name.charAt(0)}</div><div><strong>{item.name}</strong><small>on {item.post.title}</small><p>{item.text}</p></div></div>)}{comments.filter((item) => item.approved && !item.reply).length === 0 && <p className="empty-note">You’re all caught up.</p>}</section></div>
        </>}
        {section === "Content" && <section className="full-table-section"><div className="subsection-heading"><div><p className="eyebrow">LIBRARY / {posts.length} ITEMS</p><h2>All content</h2></div></div><ContentTable posts={posts} onEdit={(post) => setForm({ ...post })} onDelete={onDelete} /></section>}
        {section === "Comments" && <section className="comment-management"><div className="subsection-heading"><div><p className="eyebrow">COMMUNITY / {comments.length} NOTES</p><h2>Comments & replies</h2></div></div>{comments.map((item) => <article className="managed-comment" key={item.id}><div className="comment-avatar">{item.name.charAt(0)}</div><div className="managed-comment-body"><div className="comment-byline"><strong>{item.name}</strong><time>{item.date}</time><span className={item.approved ? "approval-tag approved" : "approval-tag"}>{item.approved ? "Published" : "Needs review"}</span></div><p>{item.text}</p><small>On <b>{item.post.title}</b></small>{item.reply && <div className="existing-reply"><strong>Your reply</strong><p>{item.reply}</p></div>}<div className="comment-actions">{!item.approved && <button type="button" className="text-action" onClick={() => updateComment(item.post, item, { approved: true })}>Approve</button>}<button type="button" className="text-action muted-action" onClick={() => updateComment(item.post, item, { approved: false })}>{item.approved ? "Hide" : "Keep hidden"}</button><form className="reply-form" onSubmit={(event) => { event.preventDefault(); const text = commentDrafts[item.id] || item.reply; if (text) updateComment(item.post, item, { reply: text, approved: true }); }}><input aria-label={`Reply to ${item.name}`} placeholder="Write a reply..." value={commentDrafts[item.id] ?? item.reply} onChange={(event) => setCommentDrafts({ ...commentDrafts, [item.id]: event.target.value })} /><button type="submit" aria-label="Send reply">↗</button></form></div></div></article>)}{comments.length === 0 && <p className="empty-note">No comments yet. Your viewers’ notes will show up here.</p>}</section>}
      </section>
      {form && <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setForm(null); }}><form className="edit-modal" onSubmit={submitContent}><button className="icon-button modal-close" type="button" onClick={() => setForm(null)} aria-label="Close editor">×</button><p className="eyebrow">CONTENT EDITOR</p><h2>{form.id ? "Edit story" : "Create a story"}</h2><label htmlFor="story-title">Title</label><input id="story-title" value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} required /><label htmlFor="story-description">Description</label><textarea id="story-description" rows="4" value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} required /><div className="form-two-col"><div><label htmlFor="story-category">Category</label><select id="story-category" value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })}><option>Field notes</option><option>Creator craft</option><option>Audio journal</option><option>Culture</option></select></div><div><label htmlFor="story-type">Content type</label><select id="story-type" value={form.contentType || "other"} onChange={(event) => setForm({ ...form, contentType: event.target.value })}><option value="video">Video</option><option value="article">Article</option><option value="image">Image</option><option value="podcast">Podcast</option><option value="other">Other</option></select></div><div><label htmlFor="story-status">Status</label><select id="story-status" value={form.status} onChange={(event) => setForm({ ...form, status: event.target.value })}><option value="draft">Draft</option><option value="scheduled">Scheduled</option><option value="published">Published</option></select></div><div><label htmlFor="story-published">Publication date</label><input id="story-published" type="date" value={form.publishedAt || ""} onChange={(event) => setForm({ ...form, publishedAt: event.target.value })} required /></div></div>{form.status === "scheduled" && <><label htmlFor="story-scheduled">Schedule publication</label><input id="story-scheduled" type="datetime-local" value={form.scheduledAt ? new Date(form.scheduledAt).toISOString().slice(0, 16) : ""} onChange={(event) => setForm({ ...form, scheduledAt: event.target.value ? new Date(event.target.value).toISOString() : "" })} required /></>}
          <label htmlFor="story-cover">Cover image URL</label><input id="story-cover" type="url" value={form.cover} onChange={(event) => setForm({ ...form, cover: event.target.value })} placeholder="https://..." required /><label htmlFor="story-media">Media or story URL</label><input id="story-media" type="url" value={form.mediaUrl} onChange={(event) => setForm({ ...form, mediaUrl: event.target.value })} placeholder="https://..." required />{formError && <p className="form-error" role="alert">{formError}</p>}<button className="button button-dark form-submit" type="submit">Save story <span aria-hidden="true">↗</span></button></form></div>}
    </main>
  );
}

function ContentTable({ posts, onEdit, onDelete }) {
  return <div className="content-table-wrap"><table className="content-table"><thead><tr><th>STORY</th><th>STATUS</th><th>VIEWS</th><th>LIKES</th><th aria-label="Actions" /></tr></thead><tbody>{posts.map((post) => <tr key={post.id}><td><div className="table-story"><img src={post.cover} alt="" /><div><strong>{post.title}</strong><small>{post.category} · {new Date(post.publishedAt).toLocaleDateString("en", { month: "short", day: "numeric" })}</small></div></div></td><td><span className={`status-tag ${post.status}`}>{post.status}</span></td><td>{numberLabel(post.views)}</td><td>{numberLabel(post.likes)}</td><td><div className="table-actions"><button type="button" onClick={() => onEdit(post)} aria-label={`Edit ${post.title}`}>Edit</button><button type="button" onClick={() => onDelete(post.id)} aria-label={`Delete ${post.title}`}>Delete</button></div></td></tr>)}</tbody></table></div>;
}