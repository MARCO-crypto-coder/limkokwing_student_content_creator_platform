import { useEffect, useState } from "react";
import CreatorStudio from "./CreatorStudio.jsx";
import ViewerPortal from "./ViewerPortal.jsx";
import { initialContent } from "./content.js";
import {
  fetchCreatorContent,
  fetchPublicContent,
  loginCreator,
  loginWithGoogle,
  signupCreator,
  postComment,
  recordView,
  removeContent,
  saveContent,
  toggleLike,
} from "./creatorApi.js";
import "./creator.css";

export default function CreatorApp() {
  const [view, setView] = useState("viewer");
  const [posts, setPosts] = useState(initialContent);
  const [token, setToken] = useState(() => localStorage.getItem("creator-token"));
  const [syncState, setSyncState] = useState("loading");

  useEffect(() => {
    fetchPublicContent()
      .then((content) => {
        setPosts(content);
        setSyncState("ready");
      })
      .catch(() => {
        setPosts(initialContent);
        setSyncState("offline");
      });
  }, []);

  async function handleLogin(email, password) {
    const result = await loginCreator(email, password);
    localStorage.setItem("creator-token", result.token);
    setToken(result.token);
    const creatorPosts = await fetchCreatorContent(result.token);
    setPosts(creatorPosts);
  }

  async function handleSignup(email, password) {
    const result = await signupCreator(email, password);
    localStorage.setItem("creator-token", result.token);
    setToken(result.token);
    const creatorPosts = await fetchCreatorContent(result.token);
    setPosts(creatorPosts);
  }

  async function handleGoogleLogin(credential) {
    const result = await loginWithGoogle(credential);
    localStorage.setItem("creator-token", result.token);
    setToken(result.token);
    setPosts(await fetchCreatorContent(result.token));
  }

  async function handleLogout() {
    localStorage.removeItem("creator-token");
    setToken(null);
    setPosts(await fetchPublicContent());
    setView("viewer");
  }

  async function handleSave(post) {
    const saved = await saveContent(post, token);
    setPosts((current) => {
      const exists = current.some((item) => item.id === saved.id);
      return exists
        ? current.map((item) => item.id === saved.id ? saved : item)
        : [saved, ...current];
    });
    return saved;
  }

  async function handleDelete(id) {
    await removeContent(id, token);
    setPosts((current) => current.filter((post) => post.id !== id));
  }

  async function handleLike(id) {
    const updated = await toggleLike(id);
    setPosts((current) => current.map((post) => post.id === id ? updated : post));
    return updated;
  }

  async function handleView(id) {
    const updated = await recordView(id);
    setPosts((current) => current.map((post) => post.id === id ? updated : post));
    return updated;
  }

  async function handleComment(id, text, name) {
    const updated = await postComment(id, text, name);
    setPosts((current) => current.map((post) => post.id === id ? updated : post));
    return updated;
  }

  return (
    <div className="creator-app">
      <header className="site-header">
        <a className="wordmark" href="#home" onClick={() => setView("viewer")}>
          <span className="wordmark-symbol">M</span>
          <span>Mpho Nthebe <small>STUDIO</small></span>
        </a>
        <nav className="main-nav" aria-label="Main navigation">
          <button className={view === "viewer" ? "nav-item is-active" : "nav-item"} type="button" onClick={() => setView("viewer")}>Discover</button>
          <button className={view === "studio" ? "nav-item is-active" : "nav-item"} type="button" onClick={() => setView("studio")}>Creator studio</button>
        </nav>
        <div className="header-note"><span className={`sync-dot ${syncState}`} />{syncState === "ready" ? "Connected" : syncState === "loading" ? "Connecting" : "Preview mode"}</div>
      </header>
      {view === "viewer" ? (
        <ViewerPortal posts={posts} onLike={handleLike} onComment={handleComment} onView={handleView} />
      ) : (
        <CreatorStudio posts={posts} token={token} onLogin={handleLogin} onSignup={handleSignup} onGoogleLogin={handleGoogleLogin} onLogout={handleLogout} onSave={handleSave} onDelete={handleDelete} />
      )}
      <footer className="site-footer"><span>MPHO NTHEBE / MASERU, LESOTHO</span><span>Made for curious minds.</span></footer>
    </div>
  );
}