import { Outlet } from "react-router-dom";
import Navbar from "./Navbar.jsx";
import { useLang } from "../context/LanguageContext.jsx";
import { isDemoMode } from "../firebase.js";

export default function Layout() {
  const { t } = useLang();
  return (
    <>
      <Navbar />
      {isDemoMode && <div className="demo-banner"><div className="container"><strong>Demo mode</strong> · Requests are saved in this browser only. Add Firebase settings to enable shared Firestore storage.</div></div>}
      <main className="container">
        <Outlet />
      </main>
      <footer className="footer">
        <div className="container">{t("footer")}</div>
      </footer>
    </>
  );
}
