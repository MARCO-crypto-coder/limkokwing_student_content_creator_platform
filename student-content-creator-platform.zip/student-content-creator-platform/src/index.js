import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { GoogleOAuthProvider } from "@react-oauth/google";
import App from "./App.jsx";
import ErrorBoundary from "./components/ErrorBoundary.jsx";
import { LanguageProvider } from "./context/LanguageContext.jsx";
import "./index.css";

const app = (
  <React.StrictMode>
    <LanguageProvider>
      <ErrorBoundary>
        <BrowserRouter>
          <App />
        </BrowserRouter>
      </ErrorBoundary>
    </LanguageProvider>
  </React.StrictMode>
);

ReactDOM.createRoot(document.getElementById("root")).render(
  process.env.REACT_APP_GOOGLE_CLIENT_ID
    ? <GoogleOAuthProvider clientId={process.env.REACT_APP_GOOGLE_CLIENT_ID}>{app}</GoogleOAuthProvider>
    : app
);
