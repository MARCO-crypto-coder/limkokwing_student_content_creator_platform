import CreatorApp from "./creator/CreatorApp.jsx";

export default function App() {
  return <CreatorApp />;
}
