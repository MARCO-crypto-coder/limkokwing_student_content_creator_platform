const jwt = require("jsonwebtoken");

function creatorAuth(request, response, next) {
  if (!process.env.JWT_SECRET) {
    return response.status(503).json({ message: "Creator authentication is not configured." });
  }

  const token = request.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) return response.status(401).json({ message: "Sign in to continue." });

  try {
    request.creator = jwt.verify(token, process.env.JWT_SECRET, { issuer: "mpho-studio" });
    return next();
  } catch {
    return response.status(401).json({ message: "Your session has expired. Sign in again." });
  }
}

module.exports = creatorAuth;