const mongoose = require("mongoose");

const creatorSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true, trim: true, lowercase: true, maxlength: 254 },
  passwordHash: { type: String },
  googleSub: { type: String, unique: true, sparse: true },
}, { timestamps: true, versionKey: false, collection: "users" });

module.exports = mongoose.model("Creator", creatorSchema);