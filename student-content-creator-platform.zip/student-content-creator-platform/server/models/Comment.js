const mongoose = require("mongoose");

const commentSchema = new mongoose.Schema({
  contentId: { type: mongoose.Schema.Types.ObjectId, ref: "Content", required: true, index: true },
  legacyId: { type: String },
  name: { type: String, required: true, trim: true, maxlength: 80 },
  text: { type: String, required: true, trim: true, maxlength: 1000 },
  date: { type: String, required: true },
  approved: { type: Boolean, default: false },
  reply: { type: String, default: "", maxlength: 1000 },
}, { timestamps: true, versionKey: false, collection: "comments" });

module.exports = mongoose.model("Comment", commentSchema);