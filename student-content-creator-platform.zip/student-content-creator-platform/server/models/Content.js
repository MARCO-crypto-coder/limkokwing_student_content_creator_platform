const mongoose = require("mongoose");

const commentSchema = new mongoose.Schema({
  id: { type: String, required: true },
  name: { type: String, required: true, maxlength: 80 },
  text: { type: String, required: true, maxlength: 1000 },
  date: { type: String, required: true },
  approved: { type: Boolean, default: false },
  reply: { type: String, default: "", maxlength: 1000 },
}, { _id: false });

const contentSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 160 },
  description: { type: String, required: true, trim: true, maxlength: 5000 },
  category: { type: String, required: true, trim: true, maxlength: 60 },
  contentType: { type: String, enum: ["video", "article", "image", "podcast", "other"], default: "other" },
  createdBy: { type: String, index: true, default: "legacy-mpho" },
  publishedAt: { type: String, required: true },
  scheduledAt: { type: Date },
  status: { type: String, enum: ["draft", "scheduled", "published"], default: "draft" },
  mediaUrl: { type: String, required: true, maxlength: 2000 },
  cover: { type: String, required: true, maxlength: 2000 },
  views: { type: Number, default: 0, min: 0 },
  likes: { type: Number, default: 0, min: 0 },
  likesBy: { type: [String], default: [] },
  readTime: { type: String, default: "New story", maxlength: 40 },
  comments: { type: [commentSchema], default: [] },
}, { timestamps: true, versionKey: false, collection: "contents" });

contentSchema.set("toJSON", {
  transform(_document, result) {
    result.id = String(result._id);
    delete result._id;
    return result;
  },
});

module.exports = mongoose.model("Content", contentSchema);