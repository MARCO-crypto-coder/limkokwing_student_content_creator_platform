const crypto = require("crypto");
const path = require("path");
require("dotenv").config({ path: path.join(__dirname, ".env") });
require("dotenv").config({ path: path.join(__dirname, "..", "atlas-credentials.env") });

const cors = require("cors");
const express = require("express");
const rateLimit = require("express-rate-limit");
const helmet = require("helmet");
const jwt = require("jsonwebtoken");
const { OAuth2Client } = require("google-auth-library");
const mongoose = require("mongoose");
const Content = require("./models/Content.js");
const Creator = require("./models/Creator.js");
const Comment = require("./models/Comment.js");
const Like = require("./models/Like.js");
const creatorAuth = require("./middleware/creatorAuth.js");
const seedContent = require("./data/seed.js");
const scrypt = require("util").promisify(require("crypto").scrypt);
const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

if (!process.env.JWT_SECRET && process.env.NODE_ENV !== "production") {
  process.env.JWT_SECRET = crypto.randomBytes(48).toString("base64url");
  console.warn("JWT_SECRET is unset; using a temporary local development secret. Sessions reset when the API restarts.");
}

function getMongoUri() {
  const username = encodeURIComponent(process.env.MONGODB_USERNAME || "");
  const password = encodeURIComponent(process.env.MONGODB_PASSWORD || "");
  const rawUri = process.env.MONGO_URI || process.env.MONGODB_URI || "";
  if (!password || password === "replace-with-new-rotated-password") return "";
  return rawUri
    .replaceAll("<db_username>", username)
    .replaceAll("<db_password>", password);
}

const app = express();
const allowedOrigins = (process.env.CLIENT_ORIGIN || "http://localhost:3000").split(",").map((origin) => origin.trim());
let databaseReady = false;
let memoryContent = seedContent.map((item) => structuredClone(item));

app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin: (origin, callback) => callback(null, !origin || allowedOrigins.includes(origin)) }));
app.use(express.json({ limit: "100kb" }));

function serialize(item) {
  const result = item?.toJSON ? item.toJSON() : { ...item, id: item.id || String(item._id) };
  delete result.likesBy;
  return result;
}

function publicFields(body, current = {}) {
  const fields = ["title", "description", "category", "contentType", "publishedAt", "scheduledAt", "status", "mediaUrl", "cover", "readTime"];
  const result = {};
  for (const field of fields) {
    if (body[field] !== undefined) result[field] = body[field];
    else if (current[field] !== undefined) result[field] = current[field];
  }
  if (body.comments !== undefined) {
    result.comments = body.comments.map((comment) => ({
      id: String(comment.id || crypto.randomUUID()),
      name: String(comment.name || "Guest viewer").slice(0, 80),
      text: String(comment.text || "").slice(0, 1000),
      date: String(comment.date || "Just now").slice(0, 60),
      approved: Boolean(comment.approved),
      reply: String(comment.reply || "").slice(0, 1000),
    }));
  }
  return result;
}

function matchesId(item, id) {
  return String(item.id || item._id) === id;
}

async function findContent(id) {
  if (databaseReady) {
    if (!mongoose.isValidObjectId(id)) return null;
    return Content.findById(id);
  }
  return memoryContent.find((item) => matchesId(item, id)) || null;
}

async function listContent(creator = false, creatorId = null) {
  if (databaseReady) {
    await Content.updateMany(
      { status: "scheduled", scheduledAt: { $lte: new Date() } },
      { $set: { status: "published", publishedAt: new Date().toISOString().slice(0, 10) } },
    );
    const filter = creator
      ? (creatorId ? { createdBy: creatorId } : { $or: [{ createdBy: "legacy-mpho" }, { createdBy: { $exists: false } }, { createdBy: null }] })
      : { status: "published" };
    return Content.find(filter).sort({ publishedAt: -1 });
  }
  const now = new Date();
  for (const item of memoryContent) {
    if (item.status === "scheduled" && item.scheduledAt && new Date(item.scheduledAt) <= now) {
      item.status = "published";
      item.publishedAt = now.toISOString().slice(0, 10);
    }
  }
  const items = creator
    ? (creatorId ? memoryContent.filter((item) => item.createdBy === creatorId) : memoryContent.filter((item) => !item.createdBy || item.createdBy === "legacy-mpho"))
    : memoryContent.filter((item) => item.status === "published");
  return items.sort((left, right) => right.publishedAt.localeCompare(left.publishedAt));
}

async function syncStoredComments(contentId, comments) {
  if (!databaseReady || !mongoose.isValidObjectId(contentId)) return;
  const ids = comments.map((comment) => String(comment.id));
  await Promise.all(comments.map((comment) => Comment.updateOne(
    { contentId, legacyId: String(comment.id) },
    { $set: { name: comment.name, text: comment.text, date: comment.date, approved: comment.approved, reply: comment.reply || "" } },
    { upsert: true, runValidators: true },
  )));
  await Comment.deleteMany({ contentId, legacyId: { $nin: ids } });
}

function safeEqual(left, right) {
  const leftValue = String(left ?? "");
  const rightValue = String(right ?? "");
  if (leftValue.length !== rightValue.length) return false;
  const leftHash = crypto.createHash("sha256").update(leftValue).digest();
  const rightHash = crypto.createHash("sha256").update(rightValue).digest();
  try {
    return crypto.timingSafeEqual(leftHash, rightHash);
  } catch (_error) {
    return false;
  }
}

app.get("/api/health", (_request, response) => {
  response.json({ ok: true, database: databaseReady ? "connected" : "preview" });
});

app.post("/api/auth/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: "draft-7", legacyHeaders: false }), async (request, response, next) => {
  const { email, password } = request.body || {};
  if (!process.env.JWT_SECRET) {
    return response.status(503).json({ message: "Creator sign-in is not configured on this server." });
  }
  try {
    const normalizedEmail = String(email || "").trim().toLowerCase();
    const creator = databaseReady ? await Creator.findOne({ email: normalizedEmail }) : null;
    const accountValid = creator && await verifyPassword(password || "", creator.passwordHash);
    const legacyValid = process.env.CREATOR_EMAIL && process.env.CREATOR_PASSWORD
      && safeEqual(normalizedEmail, process.env.CREATOR_EMAIL.trim().toLowerCase())
      && safeEqual(password || "", process.env.CREATOR_PASSWORD);
    if (!accountValid && !legacyValid) return response.status(401).json({ message: "Email or password is incorrect." });
    const subject = creator ? String(creator._id) : "creator";
    const token = jwt.sign({ sub: subject, email: normalizedEmail }, process.env.JWT_SECRET, { issuer: "mpho-studio", expiresIn: "12h" });
    return response.json({ token });
  } catch (error) {
    return next(error);
  }
});

app.post("/api/auth/signup", rateLimit({ windowMs: 60 * 60 * 1000, limit: 5, standardHeaders: "draft-7", legacyHeaders: false }), async (request, response, next) => {
  const email = String(request.body?.email || "").trim().toLowerCase();
  const password = String(request.body?.password || "");
  if (!databaseReady) return response.status(503).json({ message: "Sign up requires the account database to be connected." });
  if (!process.env.JWT_SECRET) return response.status(503).json({ message: "Creator authentication is not configured." });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    return response.status(400).json({ message: "Enter a valid email address." });
  }
  if (password.length < 12 || password.length > 256) {
    return response.status(400).json({ message: "Use a password between 12 and 256 characters." });
  }
  try {
    const salt = crypto.randomBytes(16).toString("hex");
    const derivedKey = await scrypt(password, salt, 64);
    const creator = await Creator.create({ email, passwordHash: `${salt}:${derivedKey.toString("hex")}` });
    const token = jwt.sign({ sub: String(creator._id), email }, process.env.JWT_SECRET, { issuer: "mpho-studio", expiresIn: "12h" });
    return response.status(201).json({ token });
  } catch (error) {
    if (error.code === 11000) return response.status(409).json({ message: "An account with this email already exists." });
    return next(error);
  }
});

async function verifyPassword(password, storedHash) {
  if (!storedHash) return false;
  const [salt, expectedHex] = storedHash.split(":");
  const expected = Buffer.from(expectedHex, "hex");
  const actual = await scrypt(password, salt, expected.length);
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}

app.post("/api/auth/google", rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: "draft-7", legacyHeaders: false }), async (request, response, next) => {
  const { credential } = request.body || {};
  if (!process.env.GOOGLE_CLIENT_ID || !process.env.JWT_SECRET) {
    return response.status(503).json({ message: "Google sign-in is not configured on this server." });
  }
  if (!databaseReady) return response.status(503).json({ message: "Creator account storage is unavailable." });
  if (typeof credential !== "string" || credential.length > 10000) {
    return response.status(400).json({ message: "A valid Google credential is required." });
  }
  try {
    const ticket = await googleClient.verifyIdToken({ idToken: credential, audience: process.env.GOOGLE_CLIENT_ID });
    const payload = ticket.getPayload();
    if (!payload?.sub || !payload.email || !payload.email_verified) {
      return response.status(401).json({ message: "Google must verify your email address." });
    }
    const email = payload.email.trim().toLowerCase();
    let creator = await Creator.findOne({ googleSub: payload.sub });
    if (!creator) {
      creator = await Creator.findOne({ email });
      if (creator) {
        if (creator.googleSub && creator.googleSub !== payload.sub) {
          return response.status(409).json({ message: "This email is linked to a different Google account." });
        }
        creator.googleSub = payload.sub;
        await creator.save();
      } else {
        creator = await Creator.create({ email, googleSub: payload.sub });
      }
    }
    const token = jwt.sign({ sub: String(creator._id), email, name: payload.name || "Creator" }, process.env.JWT_SECRET, { issuer: "mpho-studio", expiresIn: "12h" });
    return response.json({ token });
  } catch (error) {
    if (error.code === 11000) return response.status(409).json({ message: "This Google account is already linked." });
    if (error.name === "MongooseServerSelectionError") return response.status(503).json({ message: "Creator account storage is unavailable." });
    return response.status(401).json({ message: "Google sign-in could not be verified." });
  }
});

app.get("/api/content", async (_request, response, next) => {
  try {
    response.json((await listContent()).map(serialize));
  } catch (error) {
    next(error);
  }
});

app.get("/api/contents", async (_request, response, next) => {
  try {
    response.json((await listContent()).map(serialize));
  } catch (error) {
    next(error);
  }
});

app.get("/api/contents/:id", async (request, response, next) => {
  try {
    const item = await findContent(request.params.id);
    if (!item || item.status !== "published") return response.status(404).json({ message: "Content not found." });
    response.json(serialize(item));
  } catch (error) {
    next(error);
  }
});

app.get("/api/creator/content", creatorAuth, async (request, response, next) => {
  try {
    response.json((await listContent(true, request.creator.sub)).map(serialize));
  } catch (error) {
    next(error);
  }
});

app.post("/api/creator/content", creatorAuth, async (request, response, next) => {
  try {
    const fields = publicFields(request.body || {});
    fields.createdBy = request.creator.sub;
    if (databaseReady) {
      const created = await Content.create(fields);
      return response.status(201).json(serialize(created));
    }
    const created = { ...fields, id: crypto.randomUUID(), views: 0, likes: 0, comments: [] };
    memoryContent.unshift(created);
    return response.status(201).json(serialize(created));
  } catch (error) {
    next(error);
  }
});

app.post("/api/contents", creatorAuth, async (request, response, next) => {
  try {
    const fields = publicFields(request.body || {});
    if (databaseReady) return response.status(201).json(serialize(await Content.create(fields)));
    const created = { ...fields, id: crypto.randomUUID(), views: 0, likes: 0, comments: [] };
    memoryContent.unshift(created);
    return response.status(201).json(serialize(created));
  } catch (error) {
    next(error);
  }
});

app.put("/api/creator/content/:id", creatorAuth, async (request, response, next) => {
  try {
    const current = await findContent(request.params.id);
    if (!current) return response.status(404).json({ message: "Story not found." });
    const ownerMatches = !current.createdBy || current.createdBy === request.creator.sub || (current.createdBy === "legacy-mpho" && request.creator.email === process.env.CREATOR_EMAIL?.trim().toLowerCase());
    if (!ownerMatches) return response.status(403).json({ message: "This story belongs to another creator." });
    const fields = publicFields(request.body || {}, current);
    if (databaseReady) {
      const updated = await Content.findByIdAndUpdate(request.params.id, { ...fields, createdBy: request.creator.sub }, { new: true, runValidators: true });
      if (fields.comments) await syncStoredComments(request.params.id, fields.comments);
      return response.json(serialize(updated));
    }
    Object.assign(current, fields, { createdBy: request.creator.sub });
    return response.json(serialize(current));
  } catch (error) {
    next(error);
  }
});

app.put("/api/contents/:id", creatorAuth, async (request, response, next) => {
  try {
    const current = await findContent(request.params.id);
    if (!current) return response.status(404).json({ message: "Content not found." });
    const fields = publicFields(request.body || {}, current);
    if (databaseReady) {
      const updated = await Content.findByIdAndUpdate(request.params.id, fields, { new: true, runValidators: true });
      if (fields.comments) await syncStoredComments(request.params.id, fields.comments);
      return response.json(serialize(updated));
    }
    Object.assign(current, fields);
    return response.json(serialize(current));
  } catch (error) {
    next(error);
  }
});

app.delete("/api/creator/content/:id", creatorAuth, async (request, response, next) => {
  try {
    const current = await findContent(request.params.id);
    if (!current) return response.status(404).json({ message: "Story not found." });
    const ownerMatches = !current.createdBy || current.createdBy === request.creator.sub || (current.createdBy === "legacy-mpho" && request.creator.email === process.env.CREATOR_EMAIL?.trim().toLowerCase());
    if (!ownerMatches) return response.status(403).json({ message: "This story belongs to another creator." });
    if (databaseReady) {
      await Promise.all([
        Content.findByIdAndDelete(request.params.id),
        Comment.deleteMany({ contentId: request.params.id }),
        Like.deleteMany({ contentId: request.params.id }),
      ]);
    }
    else memoryContent = memoryContent.filter((item) => !matchesId(item, request.params.id));
    return response.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

app.delete("/api/contents/:id", creatorAuth, async (request, response, next) => {
  try {
    const current = await findContent(request.params.id);
    if (!current) return response.status(404).json({ message: "Content not found." });
    if (databaseReady) {
      await Promise.all([
        Content.findByIdAndDelete(request.params.id),
        Comment.deleteMany({ contentId: request.params.id }),
        Like.deleteMany({ contentId: request.params.id }),
      ]);
    }
    else memoryContent = memoryContent.filter((item) => !matchesId(item, request.params.id));
    return response.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

async function applyLike(request, response, next) {
  try {
    const viewerId = String(request.get("x-viewer-id") || "").trim();
    if (!viewerId || viewerId.length > 128) return response.status(400).json({ message: "A valid viewer identity is required." });
    const current = await findContent(request.params.id);
    if (!current || current.status !== "published") return response.status(404).json({ message: "Story not found." });
    if (databaseReady) {
      const updated = await Content.findOneAndUpdate(
        { _id: request.params.id, likesBy: { $ne: viewerId } },
        { $addToSet: { likesBy: viewerId }, $inc: { likes: 1 } },
        { new: true },
      );
      if (!updated) return response.json({ ...serialize(current), liked: true, alreadyLiked: true });
      try {
        await Like.create({ contentId: request.params.id, viewerId });
      } catch (error) {
        if (error.code === 11000) {
          const rolledBack = await Content.findByIdAndUpdate(request.params.id, { $pull: { likesBy: viewerId }, $inc: { likes: -1 } }, { new: true });
          return response.json({ ...serialize(rolledBack), liked: true, alreadyLiked: true });
        }
        throw error;
      }
      return response.json({ ...serialize(updated), liked: true });
    }
    current.likesBy ||= [];
    if (current.likesBy.includes(viewerId)) return response.json({ ...serialize(current), liked: true, alreadyLiked: true });
    current.likesBy.push(viewerId);
    current.likes = (current.likes || 0) + 1;
    return response.json({ ...serialize(current), liked: true });
  } catch (error) {
    next(error);
  }
}

app.post("/api/content/:id/like", rateLimit({ windowMs: 60 * 1000, limit: 60, standardHeaders: "draft-7", legacyHeaders: false }), applyLike);
app.post("/api/likes", rateLimit({ windowMs: 60 * 1000, limit: 60, standardHeaders: "draft-7", legacyHeaders: false }), (request, response, next) => {
  request.params.id = String(request.body?.contentId || "");
  request.headers["x-viewer-id"] = String(request.body?.viewerId || request.get("x-viewer-id") || "");
  return applyLike(request, response, next);
});

app.post("/api/content/:id/view", rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: "draft-7", legacyHeaders: false }), async (request, response, next) => {
  try {
    const current = await findContent(request.params.id);
    if (!current || current.status !== "published") return response.status(404).json({ message: "Story not found." });
    if (databaseReady) return response.json(serialize(await Content.findByIdAndUpdate(request.params.id, { $inc: { views: 1 } }, { new: true })));
    current.views = (current.views || 0) + 1;
    return response.json(serialize(current));
  } catch (error) {
    next(error);
  }
});

app.post("/api/content/:id/comments", rateLimit({ windowMs: 60 * 1000, limit: 8, standardHeaders: "draft-7", legacyHeaders: false }), async (request, response, next) => {
  try {
    const text = String(request.body?.text || "").trim();
    if (!text || text.length > 1000) return response.status(400).json({ message: "Comments must be between 1 and 1000 characters." });
    const current = await findContent(request.params.id);
    if (!current || current.status !== "published") return response.status(404).json({ message: "Story not found." });
    const name = String(request.body?.name || "Guest viewer").trim().slice(0, 80) || "Guest viewer";
    const comment = { id: crypto.randomUUID(), name, text, date: "Just now", approved: false, reply: "" };
    if (databaseReady) {
      await Comment.create({ contentId: current._id, legacyId: comment.id, name, text, date: comment.date });
      return response.json(serialize(await Content.findByIdAndUpdate(request.params.id, { $push: { comments: comment } }, { new: true, runValidators: true })));
    }
    current.comments.push(comment);
    return response.json(serialize(current));
  } catch (error) {
    next(error);
  }
});

app.post("/api/comments", rateLimit({ windowMs: 60 * 1000, limit: 8, standardHeaders: "draft-7", legacyHeaders: false }), async (request, response, next) => {
  try {
    const contentId = String(request.body?.contentId || "");
    const text = String(request.body?.text || "").trim();
    const name = String(request.body?.name || "Guest viewer").trim().slice(0, 80) || "Guest viewer";
    if (!text || text.length > 1000) return response.status(400).json({ message: "Comments must be between 1 and 1000 characters." });
    const current = await findContent(contentId);
    if (!current || current.status !== "published") return response.status(404).json({ message: "Content not found." });
    const comment = { id: crypto.randomUUID(), name, text, date: "Just now", approved: false, reply: "" };
    if (databaseReady) {
      await Comment.create({ contentId: current._id, legacyId: comment.id, name, text, date: comment.date });
      await Content.findByIdAndUpdate(contentId, { $push: { comments: comment } }, { runValidators: true });
    } else current.comments.push(comment);
    return response.status(201).json(comment);
  } catch (error) {
    next(error);
  }
});

app.get("/api/comments/:contentId", async (request, response, next) => {
  try {
    const current = await findContent(request.params.contentId);
    if (!current || current.status !== "published") return response.status(404).json({ message: "Content not found." });
    const embedded = (current.comments || []).filter((comment) => comment.approved);
    if (!databaseReady) return response.json(embedded);
    const stored = await Comment.find({ contentId: current._id, approved: true }).lean();
    const embeddedIds = new Set(embedded.map((comment) => String(comment.id)));
    const additional = stored
      .filter((comment) => !embeddedIds.has(String(comment.legacyId)))
      .map((comment) => ({ ...comment, id: String(comment._id) }));
    response.json([...embedded, ...additional]);
  } catch (error) {
    next(error);
  }
});

app.get("/api/dashboard/stats", creatorAuth, async (request, response, next) => {
  try {
    const items = await listContent(true, request.creator.sub);
    const comments = items.flatMap((item) => item.comments || []);
    response.json({
      total: items.length,
      published: items.filter((item) => item.status === "published").length,
      drafts: items.filter((item) => item.status === "draft").length,
      scheduled: items.filter((item) => item.status === "scheduled").length,
      comments: comments.length,
      pendingComments: comments.filter((item) => !item.approved).length,
      views: items.reduce((total, item) => total + (item.views || 0), 0),
      likes: items.reduce((total, item) => total + (item.likes || 0), 0),
    });
  } catch (error) {
    next(error);
  }
});

app.use((error, _request, response, _next) => {
  if (error.name === "ValidationError" || error.name === "CastError") {
    return response.status(400).json({ message: "The submitted content is invalid." });
  }
  console.error(error);
  return response.status(500).json({ message: "The server could not complete the request." });
});

const port = Number(process.env.PORT) || 5000;
if (require.main === module) {
  app.listen(port, () => console.log(`Creator API listening on port ${port}`));

  const mongoUri = getMongoUri();
  if (mongoUri) {
    const databaseName = new URL(mongoUri).pathname.replace(/^\//, "").split("/")[0] || "mpho_creator";
    mongoose.connect(mongoUri, { dbName: databaseName })
      .then(async () => {
        databaseReady = true;
        if (await Content.countDocuments() === 0) await Content.insertMany(seedContent.map(({ id, ...item }) => item));
        const addedStories = new Set(["market-day-colors", "making-time-to-make", "rain-on-the-roof"]);
        for (const { id, ...item } of seedContent.filter((story) => addedStories.has(story.id))) {
          if (!await Content.exists({ title: item.title })) await Content.create(item);
        }
          await Like.syncIndexes();
        console.log("MongoDB connected; seed content is ready.");
      })
      .catch((error) => console.error("MongoDB connection failed; using in-memory preview data.", error.message));
  }
}

module.exports = app;