# Limkokwing Student Creator Studio

A React viewer portal and private creator dashboard for a fictional Lesotho-based creator. The public library supports search, category filters, story details, likes, and moderated comments. The creator studio manages drafts, scheduled and published stories, comment approval/replies, and engagement totals.

## Technology
React 18 · Express · MongoDB/Mongoose · MongoDB Atlas · JWT · Helmet · GitHub-ready deployment configuration

## Local development
1. Install frontend dependencies with `npm install`.
2. Install API dependencies with `npm install --prefix server`.
3. Configure `MONGO_URI` in `server/.env`, or provide `MONGODB_URI`, `MONGODB_USERNAME`, and `MONGODB_PASSWORD` in the root `atlas-credentials.env`. The app uses the `mpho_creator` database when the URI does not specify one. Keep credential files private and never commit them. Set `JWT_SECRET` and `GOOGLE_CLIENT_ID` in `server/.env`; set the matching `REACT_APP_GOOGLE_CLIENT_ID` in the root `.env`. Add the frontend origin to the Google OAuth client's authorized JavaScript origins. `CREATOR_EMAIL` and `CREATOR_PASSWORD` are optional legacy owner credentials.
4. Start the API in one terminal with `npm run server`.
5. Start React in another terminal with `npm start`.

The API seeds five sample stories when Atlas is empty. Without Atlas, it uses in-memory seed data; changes disappear when the server restarts. If the API is unavailable, the viewer uses browser-local preview data. Set `REACT_APP_API_URL` in the root `.env` if the API is not at `http://localhost:5000/api`.

## API
| Method | Path | Access | Purpose |
|---|---|---|---|
| `GET` | `/api/health` | Public | Health and database mode |
| `GET` | `/api/content` | Public | Published content |
| `POST` | `/api/content/:id/view` | Public, rate-limited | Record a story view |
| `POST` | `/api/content/:id/like` | Public, rate-limited | Like a story |
| `POST` | `/api/content/:id/comments` | Public, rate-limited | Submit a pending comment |
| `POST` | `/api/auth/login` | Public, rate-limited | Creator sign-in; returns a 12-hour JWT |
| `POST` | `/api/auth/google` | Public, rate-limited | Verifies Google ID token and signs in or links a creator account |
| `POST` | `/api/auth/signup` | Public, rate-limited | Creates a creator account when MongoDB is connected |
| `GET` | `/api/creator/content` | Creator JWT | All content and comments |
| `POST` | `/api/creator/content` | Creator JWT | Create a story |
| `PUT` | `/api/creator/content/:id` | Creator JWT | Edit story or moderate comments |
| `DELETE` | `/api/creator/content/:id` | Creator JWT | Delete a story |

## Deployment
Push the project to a GitHub repository before creating hosted services.

### API on Render
1. Create a Render Web Service connected to the repository.
2. Set root directory to `server`, build command to `npm install`, and start command to `npm start`.
3. Add `MONGO_URI`, `JWT_SECRET`, and `CLIENT_ORIGIN` environment variables. `CLIENT_ORIGIN` must be the deployed frontend origin. `CREATOR_EMAIL` and `CREATOR_PASSWORD` remain optional for a legacy owner login; creator sign-up requires MongoDB.
4. In MongoDB Atlas, create a database user, allow the Render service's network access, and use the database connection string as `MONGO_URI`.

### Frontend on Vercel
1. Import the same GitHub repository into Vercel.
2. Set `REACT_APP_API_URL` to `https://<your-render-service>.onrender.com/api`.
3. Build with `npm run build`; output directory is `build`.
4. Add an SPA rewrite so routes resolve to `/index.html` if you add frontend routes later.
5. Set Render's `CLIENT_ORIGIN` to the final Vercel URL and redeploy the API.

Netlify can host the same `build` output with `npm run build` and `build` as the publish directory. A real public URL requires the owner to create the GitHub, Atlas, Render, and Vercel/Netlify accounts and configure their credentials; no deployment has been performed from this local workspace.

## Security notes
Creator passwords and JWT secrets are server-only environment variables. Never commit either `.env` file. Signup uses salted scrypt password hashes and rate limits registration; signed-up creators share access to the studio content. Public comments are hidden by default until the creator approves them. Change the demo's display identity and seed stories to match the submitted project before assessment.
